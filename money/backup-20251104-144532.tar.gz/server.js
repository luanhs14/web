const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(__dirname));

// Inicializar banco de dados
db.initDatabase();

// ==================== ROUTES ====================

// Servir o index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// ========== ACCOUNTS ==========

// GET - Listar todas as contas
app.get('/api/accounts', (req, res) => {
    try {
        const accounts = db.getAllAccounts();
        res.json({ success: true, data: accounts });
    } catch (error) {
        console.error('Erro ao buscar contas:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// GET - Buscar conta por ID
app.get('/api/accounts/:id', (req, res) => {
    try {
        const account = db.getAccountById(req.params.id);
        if (!account) {
            return res.status(404).json({ success: false, error: 'Conta não encontrada' });
        }
        res.json({ success: true, data: account });
    } catch (error) {
        console.error('Erro ao buscar conta:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// POST - Criar nova conta
app.post('/api/accounts', (req, res) => {
    try {
        const account = req.body;

        // Validações básicas
        if (!account.name || !account.category || !account.dueDay) {
            return res.status(400).json({
                success: false,
                error: 'Campos obrigatórios faltando'
            });
        }

        // Gerar ID se não existir
        if (!account.id) {
            account.id = Date.now().toString();
        }

        // Adicionar timestamp se não existir
        if (!account.createdAt) {
            account.createdAt = new Date().toISOString();
        }

        const newAccount = db.createAccount(account);
        res.status(201).json({ success: true, data: newAccount });
    } catch (error) {
        console.error('Erro ao criar conta:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// PUT - Atualizar conta
app.put('/api/accounts/:id', (req, res) => {
    try {
        const { id } = req.params;
        const account = req.body;

        // Verificar se conta existe
        const existingAccount = db.getAccountById(id);
        if (!existingAccount) {
            return res.status(404).json({ success: false, error: 'Conta não encontrada' });
        }

        const updatedAccount = db.updateAccount(id, account);
        res.json({ success: true, data: updatedAccount });
    } catch (error) {
        console.error('Erro ao atualizar conta:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// DELETE - Deletar conta
app.delete('/api/accounts/:id', (req, res) => {
    try {
        const { id } = req.params;
        const deleted = db.deleteAccount(id);

        if (!deleted) {
            return res.status(404).json({ success: false, error: 'Conta não encontrada' });
        }

        res.json({ success: true, message: 'Conta deletada com sucesso' });
    } catch (error) {
        console.error('Erro ao deletar conta:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// DELETE - Deletar todas as contas
app.delete('/api/accounts', (req, res) => {
    try {
        const count = db.deleteAllAccounts();
        res.json({
            success: true,
            message: `${count} conta(s) deletada(s) com sucesso`
        });
    } catch (error) {
        console.error('Erro ao deletar contas:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ========== SETTINGS ==========

// GET - Buscar configurações
app.get('/api/settings', (req, res) => {
    try {
        const settings = db.getSettings();
        res.json({ success: true, data: settings });
    } catch (error) {
        console.error('Erro ao buscar configurações:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// PUT - Atualizar configurações
app.put('/api/settings', (req, res) => {
    try {
        const settings = req.body;
        db.updateSettings(settings);
        res.json({ success: true, data: settings });
    } catch (error) {
        console.error('Erro ao atualizar configurações:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// PUT - Atualizar apenas EmailJS
app.put('/api/settings/emailjs', (req, res) => {
    try {
        const emailjs = req.body;
        db.updateEmailjs(emailjs);
        res.json({ success: true, data: emailjs });
    } catch (error) {
        console.error('Erro ao atualizar EmailJS:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// PUT - Atualizar apenas notificações
app.put('/api/settings/notifications', (req, res) => {
    try {
        const notifications = req.body;
        db.updateNotifications(notifications);
        res.json({ success: true, data: notifications });
    } catch (error) {
        console.error('Erro ao atualizar notificações:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// PUT - Atualizar apenas tema
app.put('/api/settings/theme', (req, res) => {
    try {
        const { theme } = req.body;
        db.updateTheme(theme);
        res.json({ success: true, data: { theme } });
    } catch (error) {
        console.error('Erro ao atualizar tema:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ========== HEALTH CHECK ==========

app.get('/api/health', (req, res) => {
    res.json({
        success: true,
        message: 'API Money Planner está rodando!',
        timestamp: new Date().toISOString()
    });
});

// Tratamento de erros 404
app.use((req, res) => {
    res.status(404).json({ success: false, error: 'Rota não encontrada' });
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`\n🚀 Servidor Money Planner rodando!`);
    console.log(`📍 URL: http://localhost:${PORT}`);
    console.log(`💾 Banco de dados: JSON (data.json)`);
    console.log(`⚡ Pronto para usar!\n`);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n👋 Encerrando servidor...');
    db.close();
    process.exit(0);
});
